const deviceModule = require('..').device;
const cmdLineProcess = require('./lib/cmdline');
var fs = require("fs");


var device = deviceModule({
clientId: "myThingName",
caPath: "cert11/rootcert.pem",
certPath: "cert11/cert.pem",
keyPath: "cert11/privateKey.pem",
region: 'us-west-2'
});
var fs = require('fs'),
    bite_size = 256,
    readbytes = 0,
    file;
var str;
device.on('connect', function() {
   console.log('connect....................................');
   
   });
fs.open('data.txt', 'r', function(err, fd) { file = fd; readsome(); });

function readsome() {
    var stats = fs.fstatSync(file);
    if(stats.size<readbytes+1) {
	fs.open('data.txt', 'r+', function(err, fd) {
   if (err) {
       return console.error(err);
   }
  fs.readFile('data.txt', function (err, data) {
   if (err) {
       return console.error(err);
   }
str="{\"temp\" : "+data.toString()+"}";
console.log(str);
});
device.publish('topic/tempsense', str);
//console.log("publish.............");
function sleep(time, callback) {
    var stop = new Date().getTime();
    while(new Date().getTime() < stop + time) {
        ;
    }
    callback();
}
      // Close the opened file.
      fs.close(fd, function(err){
         if (err){
            console.log(err);
         } 
      });
   });
        setTimeout(readsome, 6000);
    }
    else {
        fs.read(file, new Buffer(bite_size), 0, bite_size, readbytes, processsome);
    }
}

function processsome(err, bytecount, buff) {
  //  console.log('Read', bytecount, 'and');
function sleep(time, callback) {
    var stop = new Date().getTime();
    while(new Date().getTime() < stop + time) {
        ;
    }
    callback();
}
    // So we continue reading from where we left:
    readbytes+=bytecount;
    

process.nextTick(readsome);
}
